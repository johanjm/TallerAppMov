package net.sgoliver.android.controlpers3

interface OnCasillaSeleccionadaListener {
    fun onCasillaSeleccionada(fila: Int, columna: Int)
}